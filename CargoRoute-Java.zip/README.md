# CargoRoute (Java)

CargoRoute is a standalone Java desktop application for multimodal freight planning and fleet operations. It includes a Swing dashboard, shipment and fleet views, operational summaries, and a capacity-aware route optimizer.

## Run

Requires JDK 17 or later. With Maven installed:

```powershell
mvn compile exec:java
```

Or compile and launch directly without third-party dependencies:

```powershell
javac -d out (Get-ChildItem -Recurse src/main/java -Filter *.java | ForEach-Object FullName)
java -cp out com.sih2026.app.CargoRouteApp
```

## Route optimization

The route planner models each scheduled road, rail, or air service as a directed edge with a cargo capacity and unit cost. It uses successive shortest augmenting paths with Bellman–Ford over the residual graph to maximize delivered flow and minimize total cost for that flow. Cargo and service capacities are represented in integer kilograms; costs are represented in milli-paise per kilogram.

The included hubs, service schedules, capacities, and rates are illustrative demo data. The application does not connect to live carrier or tracking systems.

## Project layout

- `src/main/java/com/sih2026/app/` — CargoRoute application and min-cost max-flow implementation.
- `src/main/java/com/sih2026/generator/` — retained Java file-generation utilities.

The previous frontend sources are retained in the repository to preserve existing local work; the Java application is the documented and runnable project entry point.
