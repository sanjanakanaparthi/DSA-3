import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Vehicle, Driver, Shipment, IntermediateOpportunity, 
  MaintenanceRecord, ExpenseRecord, SystemAlert, ScenarioParameters 
} from '../types';
import { INITIAL_VEHICLES } from '../data/vehicles';
import { INITIAL_DRIVERS } from '../data/drivers';
import { INITIAL_SHIPMENTS } from '../data/shipments';
import { INITIAL_OPPORTUNITIES } from '../data/opportunities';
import { INITIAL_MAINTENANCE } from '../data/maintenance';
import { INITIAL_EXPENSES } from '../data/expenses';
import { INITIAL_ALERTS } from '../data/alerts';

interface LogisticsContextType {
  vehicles: Vehicle[];
  drivers: Driver[];
  shipments: Shipment[];
  opportunities: IntermediateOpportunity[];
  maintenance: MaintenanceRecord[];
  expenses: ExpenseRecord[];
  alerts: SystemAlert[];
  unreadAlertsCount: number;
  scenarioParams: ScenarioParameters;
  
  // Computed Financials & KPIs
  kpis: {
    totalVehicles: number;
    activeVehicles: number;
    availableVehicles: number;
    maintenanceVehicles: number;
    delayedVehicles: number;
    activeShipments: number;
    deliveredShipments: number;
    fleetUtilizationPct: number;
    totalRevenue: number;
    totalOperatingCost: number;
    totalProfit: number;
    profitMarginPct: number;
    availableWeightCapacityTons: number;
    availableVolumeCapacityM3: number;
    avgFuelCostPerKm: number;
    totalDistanceTraveledKm: number;
  };

  // Actions
  acceptIntermediateShipment: (oppId: string) => boolean;
  createShipment: (newShipment: Partial<Shipment>) => void;
  approveShipment: (shipmentId: string) => void;
  rejectShipment: (shipmentId: string) => void;
  updateVehicleStatus: (vehicleId: string, status: Vehicle['status']) => void;
  setScenarioParams: React.Dispatch<React.SetStateAction<ScenarioParameters>>;
  updateScenarioParam: <K extends keyof ScenarioParameters>(key: K, value: ScenarioParameters[K]) => void;
  resetScenarioParams: () => void;
  markAlertRead: (alertId: string) => void;
  markAllAlertsRead: () => void;
  addExpense: (expense: Omit<ExpenseRecord, 'id'>) => void;
  addMaintenanceRecord: (record: Omit<MaintenanceRecord, 'id'>) => void;
  getVehicleById: (id: string) => Vehicle | undefined;
  getDriverById: (id: string) => Driver | undefined;
}

const DEFAULT_SCENARIO: ScenarioParameters = {
  dieselPricePerL: 95,
  freightRatePerKm: 42,
  driverCostMultiplier: 1.0,
  maintenanceRateMultiplier: 1.0,
  fleetUtilizationPct: 78.4,
  fleetSize: 48,
  monthlyShipmentVolumeTons: 3200,
  avgTripDistanceKm: 1250
};

const LogisticsContext = createContext<LogisticsContextType | undefined>(undefined);

export const LogisticsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [vehicles, setVehicles] = useState<Vehicle[]>(INITIAL_VEHICLES);
  const [drivers, setDrivers] = useState<Driver[]>(INITIAL_DRIVERS);
  const [shipments, setShipments] = useState<Shipment[]>(INITIAL_SHIPMENTS);
  const [opportunities, setOpportunities] = useState<IntermediateOpportunity[]>(INITIAL_OPPORTUNITIES);
  const [maintenance, setMaintenance] = useState<MaintenanceRecord[]>(INITIAL_MAINTENANCE);
  const [expenses, setExpenses] = useState<ExpenseRecord[]>(INITIAL_EXPENSES);
  const [alerts, setAlerts] = useState<SystemAlert[]>(INITIAL_ALERTS);
  const [scenarioParams, setScenarioParams] = useState<ScenarioParameters>(DEFAULT_SCENARIO);

  // Simulated vehicle movement ticker (Frontend-only demo)
  useEffect(() => {
    const interval = setInterval(() => {
      setVehicles(prevVehicles =>
        prevVehicles.map(veh => {
          if (veh.status !== 'In Transit') return veh;
          
          const latDelta = (Math.random() - 0.48) * 0.002;
          const lngDelta = (Math.random() - 0.48) * 0.002;
          const speedVariation = Math.floor(Math.random() * 7) - 3;
          const newSpeed = Math.max(45, Math.min(75, veh.currentLocation.speedKmph + speedVariation));

          return {
            ...veh,
            currentLocation: {
              ...veh.currentLocation,
              lat: veh.currentLocation.lat + latDelta,
              lng: veh.currentLocation.lng + lngDelta,
              speedKmph: newSpeed
            },
            distanceCoveredKm: Math.min(veh.totalDistanceKm, veh.distanceCoveredKm + 0.2),
            distanceRemainingKm: Math.max(0, veh.distanceRemainingKm - 0.2),
            lastUpdated: 'Just now (Simulated Telemetry)'
          };
        })
      );
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  const unreadAlertsCount = alerts.filter(a => !a.read).length;

  // Interconnected Financial & KPI Calculations based on Base Data + Scenario Modifiers
  const fuelMultiplier = scenarioParams.dieselPricePerL / 95.0;
  const rateMultiplier = scenarioParams.freightRatePerKm / 42.0;

  // Base aggregate metrics
  const baseRevenue = shipments.reduce((sum, s) => sum + s.revenue, 0) + (scenarioParams.fleetSize - 8) * 32000;
  const totalRevenue = Math.round(baseRevenue * rateMultiplier * (scenarioParams.fleetUtilizationPct / 78.4));

  const baseFuelCost = shipments.reduce((sum, s) => sum + s.allocatedFuelCost, 0) + (scenarioParams.fleetSize - 8) * 11500;
  const adjustedFuelCost = baseFuelCost * fuelMultiplier;

  const baseDriverCost = shipments.reduce((sum, s) => sum + s.allocatedDriverCost, 0) + (scenarioParams.fleetSize - 8) * 3800;
  const adjustedDriverCost = baseDriverCost * scenarioParams.driverCostMultiplier;

  const baseMaintCost = shipments.reduce((sum, s) => sum + s.allocatedMaintenanceCost, 0) + (scenarioParams.fleetSize - 8) * 3200;
  const adjustedMaintCost = baseMaintCost * scenarioParams.maintenanceRateMultiplier;

  const otherCosts = shipments.reduce((sum, s) => sum + s.allocatedTollCost + s.allocatedHandlingCost, 0) + (scenarioParams.fleetSize - 8) * 4100;
  const totalOperatingCost = Math.round(adjustedFuelCost + adjustedDriverCost + adjustedMaintCost + otherCosts);
  const totalProfit = totalRevenue - totalOperatingCost;
  const profitMarginPct = totalRevenue > 0 ? Number(((totalProfit / totalRevenue) * 100).toFixed(1)) : 0;

  const activeVehCount = vehicles.filter(v => v.status === 'In Transit' || v.status === 'Loading').length + Math.round((scenarioParams.fleetSize - 8) * 0.75);
  const availableVehCount = vehicles.filter(v => v.status === 'Idle').length + Math.round((scenarioParams.fleetSize - 8) * 0.15);
  const maintenanceVehCount = vehicles.filter(v => v.status === 'Maintenance').length + Math.round((scenarioParams.fleetSize - 8) * 0.10);
  const delayedVehCount = vehicles.filter(v => v.status === 'Delayed').length;

  const totalAvailableWeightTons = vehicles.reduce((sum, v) => sum + Math.max(0, v.maxWeightTons - v.currentWeightTons), 0);
  const totalAvailableVolM3 = vehicles.reduce((sum, v) => sum + Math.max(0, v.maxVolumeM3 - v.currentVolumeM3), 0);

  const kpis = {
    totalVehicles: scenarioParams.fleetSize,
    activeVehicles: activeVehCount,
    availableVehicles: availableVehCount,
    maintenanceVehicles: maintenanceVehCount,
    delayedVehicles: delayedVehCount,
    activeShipments: shipments.filter(s => s.status === 'In Transit' || s.status === 'Delayed').length,
    deliveredShipments: shipments.filter(s => s.status === 'Delivered').length,
    fleetUtilizationPct: scenarioParams.fleetUtilizationPct,
    totalRevenue,
    totalOperatingCost,
    totalProfit,
    profitMarginPct,
    availableWeightCapacityTons: Number(totalAvailableWeightTons.toFixed(1)),
    availableVolumeCapacityM3: Number(totalAvailableVolM3.toFixed(1)),
    avgFuelCostPerKm: Number((scenarioParams.dieselPricePerL / 4.2).toFixed(2)),
    totalDistanceTraveledKm: 84250
  };

  // CORE DIFFERENTIATING FEATURE: Accept Intermediate Shipment
  const acceptIntermediateShipment = (oppId: string): boolean => {
    const opp = opportunities.find(o => o.id === oppId);
    if (!opp || opp.isAccepted) return false;

    // 1. Update target vehicle load & financials
    setVehicles(prev =>
      prev.map(v => {
        if (v.id !== opp.targetVehicleId) return v;
        const newWeight = Math.min(v.maxWeightTons, Number((v.currentWeightTons + opp.weightTons).toFixed(1)));
        const newVolume = Math.min(v.maxVolumeM3, Number((v.currentVolumeM3 + opp.volumeM3).toFixed(1)));
        return {
          ...v,
          currentWeightTons: newWeight,
          currentVolumeM3: newVolume,
          totalTripRevenue: v.totalTripRevenue + opp.offeredRevenue,
          totalTripCost: v.totalTripCost + opp.totalAdditionalCost,
          activeShipmentIds: [...v.activeShipmentIds, `shp-int-${Date.now()}`]
        };
      })
    );

    // 2. Insert new intermediate shipment
    const newShp: Shipment = {
      id: `shp-int-${Date.now()}`,
      trackingNumber: `CR-${opp.origin.substring(0, 3).toUpperCase()}-${opp.destination.substring(0, 3).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`,
      customerName: `${opp.shipmentTitle} Client`,
      customerCompany: 'Consolidated Freight Network',
      origin: opp.origin,
      destination: opp.destination,
      pickupDate: 'Today (Immediate)',
      deliveryDeadline: `In ${opp.deadlineHours} hours`,
      estimatedDelivery: `In ${opp.deadlineHours - 1} hours`,
      weightTons: opp.weightTons,
      volumeM3: opp.volumeM3,
      packageCount: opp.packageCount,
      goodsType: opp.goodsType,
      priority: 'Express',
      transportMode: 'Truck',
      assignedVehicleId: opp.targetVehicleId,
      assignedVehicleReg: opp.targetVehicleReg,
      status: 'In Transit',
      isIntermediateLoad: true,
      intermediatePickupStop: opp.origin,
      intermediateDropStop: opp.destination,
      revenue: opp.offeredRevenue,
      allocatedFuelCost: opp.additionalFuelCost,
      allocatedDriverCost: opp.additionalDriverCost,
      allocatedMaintenanceCost: opp.additionalMaintenanceCost,
      allocatedTollCost: opp.additionalTollCost,
      allocatedHandlingCost: 0,
      totalCost: opp.totalAdditionalCost,
      profit: opp.netAdditionalProfit,
      profitMargin: opp.incrementalMarginPct,
      currentProgressPct: 15
    };
    setShipments(prev => [newShp, ...prev]);

    // 3. Mark opportunity as accepted
    setOpportunities(prev =>
      prev.map(o => (o.id === oppId ? { ...o, isAccepted: true } : o))
    );

    // 4. Add celebration alert
    const newAlert: SystemAlert = {
      id: `alt-opp-${Date.now()}`,
      type: 'opportunity',
      severity: 'opportunity',
      title: 'Intermediate Cargo Ingested Successfully',
      message: `${opp.weightTons}T (${opp.origin} → ${opp.destination}) assigned to ${opp.targetVehicleReg}. +₹${opp.netAdditionalProfit.toLocaleString('en-IN')} net profit generated!`,
      timestamp: 'Just now',
      read: false,
      vehicleReg: opp.targetVehicleReg,
      actionUrl: `/fleet/${opp.targetVehicleId}`
    };
    setAlerts(prev => [newAlert, ...prev]);

    return true;
  };

  const createShipment = (newShipment: Partial<Shipment>) => {
    const revenue = newShipment.revenue || 35000;
    const totalCost = Math.round(revenue * 0.72);
    const profit = revenue - totalCost;
    const profitMargin = Number(((profit / revenue) * 100).toFixed(1));

    const mode = newShipment.transportMode || 'Multimodal';
    const assetIdentity = mode === 'Flight'
      ? { id: 'AIR-CRX-721', label: 'CRX 721 · VT-CR7' }
      : mode === 'Train'
        ? { id: 'RAIL-DFC-207', label: 'DFC Rake 207 · CONCOR' }
        : mode === 'Truck'
          ? { id: 'TRK-TS09AB1234', label: 'TS09AB1234 · Tata Signa' }
          : { id: 'MM-HYD-DEL-01', label: 'Road + Rail multimodal chain' };
    const shp: Shipment = {
      id: `shp-${Date.now()}`,
      trackingNumber: `CR-${(newShipment.origin || 'HYD').substring(0, 3).toUpperCase()}-${(newShipment.destination || 'DEL').substring(0, 3).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`,
      customerName: newShipment.customerName || 'Enterprise Shipper',
      customerCompany: newShipment.customerCompany || 'Commercial Logistics',
      origin: newShipment.origin || 'Hyderabad',
      destination: newShipment.destination || 'Delhi',
      pickupDate: newShipment.pickupDate || new Date().toISOString().split('T')[0],
      deliveryDeadline: newShipment.deliveryDeadline || 'In 48 hours',
      estimatedDelivery: 'On Schedule',
      weightTons: newShipment.weightTons || 5.0,
      volumeM3: newShipment.volumeM3 || 20.0,
      packageCount: newShipment.packageCount || 50,
      goodsType: newShipment.goodsType || 'General Cargo',
      priority: newShipment.priority || 'Standard',
      transportMode: mode,
      assignedVehicleId: newShipment.assignedVehicleId || 'veh-01',
      assignedVehicleReg: newShipment.assignedVehicleReg || 'TS09AB1234',
      assignedAssetId: newShipment.assignedAssetId || assetIdentity.id,
      assignedAssetLabel: newShipment.assignedAssetLabel || assetIdentity.label,
      status: 'Pending Approval',
      revenue,
      allocatedFuelCost: Math.round(totalCost * 0.55),
      allocatedDriverCost: Math.round(totalCost * 0.15),
      allocatedMaintenanceCost: Math.round(totalCost * 0.12),
      allocatedTollCost: Math.round(totalCost * 0.10),
      allocatedHandlingCost: Math.round(totalCost * 0.08),
      totalCost,
      profit,
      profitMargin,
      currentProgressPct: 0
    };

    setShipments(prev => [shp, ...prev]);
  };

  const approveShipment = (shipmentId: string) => {
    const shipment = shipments.find(s => s.id === shipmentId);
    if (!shipment || shipment.status !== 'Pending Approval') return;
    setShipments(prev => prev.map(s => s.id === shipmentId ? { ...s, status: 'Pending Pickup', estimatedDelivery: 'Route allocation in progress' } : s));
    setAlerts(prev => [{ id: `alt-approval-${Date.now()}`, type: 'shipment', severity: 'info', title: 'Cargo Approved for Dispatch', message: `${shipment.trackingNumber} has cleared commercial and capacity review. Dispatch allocation is now in progress.`, timestamp: 'Just now', read: false, actionUrl: '/shipments' }, ...prev]);
  };

  const rejectShipment = (shipmentId: string) => {
    const shipment = shipments.find(s => s.id === shipmentId);
    if (!shipment || shipment.status !== 'Pending Approval') return;
    setShipments(prev => prev.map(s => s.id === shipmentId ? { ...s, status: 'Rejected', estimatedDelivery: 'Commercial review declined' } : s));
    setAlerts(prev => [{ id: `alt-rejection-${Date.now()}`, type: 'shipment', severity: 'warning', title: 'Cargo Request Declined', message: `${shipment.trackingNumber} was declined during pre-dispatch review. No asset capacity was committed.`, timestamp: 'Just now', read: false, actionUrl: '/shipments' }, ...prev]);
  };

  const updateVehicleStatus = (vehicleId: string, status: Vehicle['status']) => {
    setVehicles(prev => prev.map(v => v.id === vehicleId ? { ...v, status } : v));
  };

  const updateScenarioParam = <K extends keyof ScenarioParameters>(key: K, value: ScenarioParameters[K]) => {
    setScenarioParams(prev => ({ ...prev, [key]: value }));
  };

  const resetScenarioParams = () => {
    setScenarioParams(DEFAULT_SCENARIO);
  };

  const markAlertRead = (alertId: string) => {
    setAlerts(prev => prev.map(a => a.id === alertId ? { ...a, read: true } : a));
  };

  const markAllAlertsRead = () => {
    setAlerts(prev => prev.map(a => ({ ...a, read: true })));
  };

  const addExpense = (expense: Omit<ExpenseRecord, 'id'>) => {
    const record: ExpenseRecord = {
      ...expense,
      id: `exp-${Date.now()}`
    };
    setExpenses(prev => [record, ...prev]);
  };

  const addMaintenanceRecord = (record: Omit<MaintenanceRecord, 'id'>) => {
    const newRecord: MaintenanceRecord = {
      ...record,
      id: `maint-${Date.now()}`
    };
    setMaintenance(prev => [newRecord, ...prev]);
  };

  const getVehicleById = (id: string) => vehicles.find(v => v.id === id || v.regNumber === id);
  const getDriverById = (id: string) => drivers.find(d => d.id === id || d.code === id);

  return (
    <LogisticsContext.Provider
      value={{
        vehicles,
        drivers,
        shipments,
        opportunities,
        maintenance,
        expenses,
        alerts,
        unreadAlertsCount,
        scenarioParams,
        kpis,
        acceptIntermediateShipment,
        createShipment,
        approveShipment,
        rejectShipment,
        updateVehicleStatus,
        setScenarioParams,
        updateScenarioParam,
        resetScenarioParams,
        markAlertRead,
        markAllAlertsRead,
        addExpense,
        addMaintenanceRecord,
        getVehicleById,
        getDriverById
      }}
    >
      {children}
    </LogisticsContext.Provider>
  );
};

export const useLogistics = () => {
  const context = useContext(LogisticsContext);
  if (!context) {
    throw new Error('useLogistics must be used within a LogisticsProvider');
  }
  return context;
};
