package com.sih2026.app;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** CargoRoute desktop logistics dashboard and min-cost max-flow planner. */
public final class CargoRouteApp {
    private static final Color NAVY = new Color(19, 31, 48), RED = new Color(194, 47, 37);
    private static final Color BG = new Color(246, 247, 249), INK = new Color(33, 43, 57), MUTED = new Color(112, 123, 138);
    private final JFrame frame = new JFrame("CargoRoute | Freight & Fleet Operations");
    private final JPanel content = new JPanel(new BorderLayout());
    private final List<Shipment> shipments = new ArrayList<>(List.of(
        new Shipment("CR-HYD-DEL-9842","Aurobindo Life Sciences","Hyderabad","Delhi",10.8,"Pharmaceuticals","In Transit",55000),
        new Shipment("CR-MUM-BLR-7719","Tata Motors CVBU","Mumbai","Bengaluru",9.2,"Automotive Parts","In Transit",48000),
        new Shipment("CR-BLR-CHE-4401","Foxconn Industrial Park","Bengaluru","Chennai",13.5,"Electronics","In Transit",28500),
        new Shipment("CR-KOL-DEL-6580","JSPL Logistics","Kolkata","Delhi",19.8,"Industrial Machinery","Delayed",92000),
        new Shipment("CR-PUN-AMD-3329","Reliance Retail","Pune","Ahmedabad",11.0,"FMCG","In Transit",42000)
    ));
    private record Shipment(String id, String customer, String origin, String destination,
                            double tons, String goods, String status, double revenue) { }

    private CargoRouteApp() { }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CargoRouteApp().show());
    }

    private void show() {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) { }
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(1080, 700)); frame.setSize(1360, 850); frame.setLocationRelativeTo(null);
        JPanel root = new JPanel(new BorderLayout()); root.setBackground(BG);
        root.add(sidebar(), BorderLayout.WEST); root.add(mainArea(), BorderLayout.CENTER);
        frame.setContentPane(root); navigate("Dashboard"); frame.setVisible(true);
    }

    private JPanel sidebar() {
        JPanel side = new JPanel(); side.setBackground(NAVY); side.setPreferredSize(new Dimension(238, 0));
        side.setLayout(new BoxLayout(side, BoxLayout.Y_AXIS)); side.setBorder(new EmptyBorder(22, 15, 18, 15));
        JLabel brand = new JLabel("◈  CARGOROUTE"); brand.setForeground(Color.WHITE); brand.setFont(new Font("SansSerif", Font.BOLD, 19));
        side.add(brand); JLabel subtitle = new JLabel("FREIGHT OPERATIONS PLATFORM"); subtitle.setForeground(new Color(155,171,191)); subtitle.setFont(new Font("Monospaced", Font.PLAIN, 9)); subtitle.setBorder(new EmptyBorder(7, 2, 27, 0)); side.add(subtitle);
        side.add(navGroup("WORKSPACE"));
        for (String item : List.of("Dashboard", "Route optimizer", "Capacity optimizer", "Shipments", "Fleet")) side.add(navButton(item));
        side.add(Box.createVerticalStrut(22)); side.add(navGroup("INSIGHTS"));
        for (String item : List.of("Reports", "About CargoRoute")) side.add(navButton(item));
        side.add(Box.createVerticalGlue());
        JLabel status = new JLabel("●  SYSTEM OPERATIONAL"); status.setForeground(new Color(126, 215, 165)); status.setFont(new Font("Monospaced", Font.BOLD, 10));
        side.add(status); JLabel version = new JLabel("Java Edition 1.0  ·  Demo data"); version.setForeground(new Color(155,171,191)); version.setFont(new Font("SansSerif", Font.PLAIN, 10)); version.setBorder(new EmptyBorder(8, 0, 0, 0)); side.add(version);
        return side;
    }

    private JLabel navGroup(String text) { JLabel l = new JLabel(text); l.setForeground(new Color(128,148,171)); l.setFont(new Font("Monospaced", Font.BOLD, 10)); l.setBorder(new EmptyBorder(0, 8, 9, 0)); return l; }
    private JButton navButton(String name) {
        JButton b = new JButton("  " + name); b.setMaximumSize(new Dimension(220, 40)); b.setAlignmentX(Component.LEFT_ALIGNMENT);
        b.setHorizontalAlignment(SwingConstants.LEFT); b.setForeground(new Color(222,229,238)); b.setBackground(NAVY); b.setBorder(new EmptyBorder(10, 8, 10, 8)); b.setFocusPainted(false); b.setFont(new Font("SansSerif", Font.PLAIN, 13));
        b.addActionListener(e -> navigate(name)); b.putClientProperty("nav", name); return b;
    }

    private JPanel mainArea() {
        JPanel area = new JPanel(new BorderLayout()); area.setBackground(BG);
        JPanel top = new JPanel(new BorderLayout()); top.setBackground(Color.WHITE); top.setBorder(BorderFactory.createMatteBorder(0,0,1,0,new Color(229,232,237))); top.setBorder(new EmptyBorder(15, 28, 15, 28));
        JLabel crumb = new JLabel("OPERATIONS   /   CARGOROUTE"); crumb.setForeground(MUTED); crumb.setFont(new Font("Monospaced", Font.BOLD, 10));
        JLabel user = new JLabel("●  Operations manager   "); user.setForeground(INK); user.setFont(new Font("SansSerif", Font.BOLD, 12)); top.add(crumb, BorderLayout.WEST); top.add(user, BorderLayout.EAST);
        content.setBackground(BG); area.add(top, BorderLayout.NORTH); area.add(content, BorderLayout.CENTER); return area;
    }

    private void navigate(String page) {
        content.removeAll(); JPanel body = new JPanel(new BorderLayout(0, 18)); body.setBackground(BG); body.setBorder(new EmptyBorder(27, 30, 28, 30));
        String title = switch (page) { case "Route optimizer" -> "Route & multimodal optimizer"; case "Capacity optimizer" -> "Network capacity optimizer"; case "About CargoRoute" -> "About CargoRoute"; default -> page; };
        String desc = switch (page) {
            case "Dashboard" -> "A live view of freight, fleet utilization, and network performance.";
            case "Route optimizer" -> "Find the least-cost feasible multimodal plan using min-cost max-flow.";
            case "Capacity optimizer" -> "Inspect how much requested cargo the network can carry within service capacities.";
            case "Shipments" -> "Track active freight orders and their dispatch status.";
            case "Fleet" -> "Fleet snapshot across active, available, and maintenance vehicles.";
            case "Reports" -> "Operational performance summary for the current demo dataset.";
            default -> "CargoRoute plans freight across road, rail, and air corridors.";
        };
        body.add(header(title, desc), BorderLayout.NORTH);
        JPanel pageContent = switch (page) {
            case "Route optimizer", "Capacity optimizer" -> optimizer(page.equals("Capacity optimizer"));
            case "Shipments" -> shipmentsPage(); case "Fleet" -> fleetPage(); case "Reports" -> reportsPage(); case "About CargoRoute" -> aboutPage(); default -> dashboardPage();
        };
        body.add(pageContent, BorderLayout.CENTER); content.add(body, BorderLayout.CENTER); content.revalidate(); content.repaint();
    }

    private JPanel header(String title, String description) {
        JPanel p = new JPanel(); p.setBackground(BG); p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        JLabel eyebrow = new JLabel("CARGOROUTE  /  LOGISTICS CONTROL TOWER"); eyebrow.setForeground(RED); eyebrow.setFont(new Font("Monospaced", Font.BOLD, 10));
        JLabel h = new JLabel(title); h.setForeground(INK); h.setFont(new Font("SansSerif", Font.BOLD, 27)); h.setBorder(new EmptyBorder(5,0,4,0));
        JLabel d = new JLabel(description); d.setForeground(MUTED); d.setFont(new Font("SansSerif", Font.PLAIN, 13)); p.add(eyebrow); p.add(h); p.add(d); return p;
    }

    private JPanel dashboardPage() {
        JPanel p = vertical(); JPanel metrics = new JPanel(new GridLayout(1,4,13,0)); metrics.setBackground(BG);
        int total = shipments.size(); long revenue = shipments.stream().mapToLong(s -> (long)s.revenue).sum();
        metrics.add(metric("ACTIVE SHIPMENTS", String.valueOf(total), "Across national corridors", "↗"));
        metrics.add(metric("FLEET VEHICLES", "08", "6 active · 1 available · 1 service", "▰"));
        metrics.add(metric("NETWORK HUBS", String.valueOf(LogisticsNetwork.HUBS.size()), "Connected across India", "⌖"));
        metrics.add(metric("BOOKED REVENUE", money(revenue), "Demo shipment portfolio", "₹")); p.add(metrics);
        JPanel lower = new JPanel(new GridLayout(1,2,13,0)); lower.setBackground(BG);
        lower.add(card("Recent shipments", shipmentTable(false))); lower.add(card("Optimization engine", engineInfo())); p.add(lower);
        return p;
    }

    private JPanel engineInfo() {
        JPanel p = new JPanel(); p.setBackground(Color.WHITE); p.setBorder(new EmptyBorder(18,18,18,18)); p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));
        JLabel status = new JLabel("READY  ·  MIN-COST MAX-FLOW"); status.setForeground(new Color(31,135,86)); status.setFont(new Font("Monospaced",Font.BOLD,11));
        p.add(status); p.add(Box.createVerticalStrut(15)); p.add(text("The route planner models each scheduled road, rail, and air service as a capacity-limited network edge.")); p.add(Box.createVerticalStrut(12));
        p.add(text("It sends cargo through the residual network until demand is met or no additional path exists, while minimizing the total transport cost.")); p.add(Box.createVerticalStrut(20));
        JButton go = primary("Plan a route  →"); go.addActionListener(e -> navigate("Route optimizer")); p.add(go); return p;
    }

    private JPanel optimizer(boolean capacityMode) {
        JPanel wrap = vertical(); JPanel form = card("Shipment request", new JPanel(new BorderLayout()));
        JPanel fields = new JPanel(new GridLayout(2,4,12,9)); fields.setBackground(Color.WHITE); fields.setBorder(new EmptyBorder(12,16,16,16));
        JComboBox<String> origin = new JComboBox<>(LogisticsNetwork.HUBS.toArray(String[]::new)); origin.setSelectedItem("Hyderabad");
        JComboBox<String> destination = new JComboBox<>(LogisticsNetwork.HUBS.toArray(String[]::new)); destination.setSelectedItem("Delhi");
        JSpinner weight = new JSpinner(new SpinnerNumberModel(8.5,0.5,120.0,0.5));
        JComboBox<String> mode = new JComboBox<>(new String[]{"Multimodal","Truck","Train","Flight"});
        fields.add(field("ORIGIN HUB",origin)); fields.add(field("DESTINATION HUB",destination)); fields.add(field("CARGO WEIGHT (TONNES)",weight)); fields.add(field("SERVICE MODE",mode));
        JComboBox<String> goods = new JComboBox<>(new String[]{"Electronics","Pharmaceuticals","Automotive Parts","General Cargo","FMCG","Textiles"});
        JComboBox<String> priority = new JComboBox<>(new String[]{"Standard","Express","Critical"});
        fields.add(field("COMMODITY",goods)); fields.add(field("PRIORITY",priority)); fields.add(field("FLOW MODEL",new JLabel("Capacity constrained · integer kg")));
        JButton solve = primary(capacityMode ? "Analyze available capacity  →" : "Compute least-cost route  →"); fields.add(solve);
        JPanel formBody=(JPanel)form.getComponent(1); formBody.add(fields,BorderLayout.CENTER); wrap.add(form);
        JPanel results = new JPanel(new BorderLayout()); results.setBackground(BG); wrap.add(results);
        solve.addActionListener(e -> {
            try {
                String from=(String)origin.getSelectedItem(), to=(String)destination.getSelectedItem();
                if (from.equals(to)) throw new IllegalArgumentException("Origin and destination must be different.");
                LogisticsNetwork.Plan plan=LogisticsNetwork.optimize(from,to,(Double)weight.getValue(),(String)mode.getSelectedItem());
                results.removeAll(); results.add(planPanel(plan,from,to,(String)goods.getSelectedItem(),(String)priority.getSelectedItem()),BorderLayout.CENTER); results.revalidate(); results.repaint();
            } catch (RuntimeException ex) { JOptionPane.showMessageDialog(frame,ex.getMessage(),"Unable to optimize",JOptionPane.WARNING_MESSAGE); }
        });
        return wrap;
    }

    private JPanel planPanel(LogisticsNetwork.Plan plan,String from,String to,String goods,String priority) {
        JPanel p=vertical(); JPanel metrics=new JPanel(new GridLayout(1,3,12,0)); metrics.setBackground(BG);
        metrics.add(metric("REQUESTED",String.format("%.3f t",plan.requestedKg()/1000.0),from+" → "+to,"↗"));
        metrics.add(metric("DELIVERABLE",String.format("%.3f t",plan.deliveredKg()/1000.0),plan.deliveredKg()==plan.requestedKg()?"Full demand served":"Network capacity reached","▰"));
        metrics.add(metric("MINIMUM TRANSPORT COST",money(plan.result().cost()/100_000.0),"Optimized total for delivered flow","₹")); p.add(metrics);
        String[] cols={"FLOW", "CORRIDOR / SERVICE", "MODE", "DISTANCE", "TIME", "CAPACITY"};
        DefaultTableModel model=new DefaultTableModel(cols,0){public boolean isCellEditable(int r,int c){return false;}};
        for(MinCostMaxFlow.Edge edge:plan.result().usedEdges()) {
            if(edge.label.equals("source")||edge.label.equals("sink")||edge.label.equals("residual")) continue;
            String[] parts=edge.label.split(" · ");
            model.addRow(new Object[]{String.format("%.3f t",edge.flow/1000.0),parts[0],parts.length>1?parts[1]:"Freight", "—", "—",String.format("%.3f t",edge.capacity/1000.0)});
        }
        JTable table=styledTable(model); JPanel routes=card("Allocated service legs  ·  " + goods + "  ·  " + priority,table); p.add(routes);
        JLabel foot=new JLabel("  Objective: minimum cost for maximum deliverable flow · Costs use demo service rates · Reverse residual edges allow reassignment"); foot.setForeground(MUTED); foot.setFont(new Font("SansSerif",Font.PLAIN,11)); p.add(foot);
        if(plan.deliveredKg()==0) { JLabel none=new JLabel("No feasible route for this mode and hub pair."); none.setForeground(RED); p.add(none); }
        return p;
    }

    private JPanel shipmentsPage(){return card("Shipment register",shipmentTable(true));}
    private JTable shipmentTable(boolean full){
        String[] cols=full?new String[]{"TRACKING ID","CUSTOMER","ORIGIN","DESTINATION","WEIGHT","COMMODITY","STATUS","REVENUE"}:new String[]{"TRACKING ID","CUSTOMER","CORRIDOR","WEIGHT","STATUS"};
        DefaultTableModel m=new DefaultTableModel(cols,0){public boolean isCellEditable(int r,int c){return false;}};
        for(Shipment s:shipments) if(full)m.addRow(new Object[]{s.id,s.customer,s.origin,s.destination,s.tons+" t",s.goods,s.status,money(s.revenue)}); else m.addRow(new Object[]{s.id,s.customer,s.origin+" → "+s.destination,s.tons+" t",s.status});
        return styledTable(m);
    }

    private JPanel fleetPage(){
        String[][] rows={{"TS09AB1234","32 FT Multi-Axle","Hyderabad → Delhi","In Transit","10.8 / 18 t"},{"AP28CD4567","Heavy Haul","Mumbai → Bengaluru","In Transit","9.2 / 16 t"},{"KA01GH2345","32 FT Multi-Axle","Bengaluru → Chennai","In Transit","13.5 / 16 t"},{"TS10EF7890","40 FT Heavy Haul","Kolkata → Delhi","Delayed","19.8 / 22 t"},{"MH12KL5678","32 FT Multi-Axle","Pune → Ahmedabad","In Transit","11 / 15 t"},{"DL01PQ9012","Refrigerated 32 FT","Available","Loading","8.5 / 14 t"},{"GJ01XY3344","14 FT City Feeder","Ahmedabad","Available","0 / 4.5 t"},{"TN02MN7788","32 FT Multi-Axle","Chennai workshop","Maintenance","—"}};
        DefaultTableModel m=new DefaultTableModel(new String[]{"REGISTRATION","VEHICLE","CURRENT ASSIGNMENT","STATUS","LOAD"},0){public boolean isCellEditable(int r,int c){return false;}};for(String[] row:rows)m.addRow(row); return card("Fleet register",styledTable(m));
    }

    private JPanel reportsPage(){
        JPanel p=vertical(); JPanel metrics=new JPanel(new GridLayout(1,3,12,0));metrics.setBackground(BG);metrics.add(metric("SHIPMENTS","5","Demo portfolio","▤"));metrics.add(metric("IN TRANSIT","4","1 shipment delayed","↗"));metrics.add(metric("TOTAL REVENUE",money(shipments.stream().mapToLong(s->(long)s.revenue).sum()),"Shipment book value","₹"));p.add(metrics);
        p.add(card("Network coverage", text("14 hubs · 22 scheduled corridors · road, rail, and air services. Route planning uses service capacities and minimizes cost for the maximum feasible cargo flow."))); return p;
    }
    private JPanel aboutPage(){ JPanel p=vertical();p.add(card("Java desktop application",text("CargoRoute is a logistics operations prototype rebuilt as a standalone Java Swing application. It includes shipment and fleet snapshots, operational reports, and a multimodal network planner.")));p.add(card("Optimization method",text("The planner builds a directed capacitated graph. Each freight service becomes a forward edge and its reverse residual edge. Successive shortest augmenting paths with Bellman–Ford find the maximum deliverable flow at minimum total cost.")));p.add(card("Units and data",text("Flow and capacity are represented in integer kilograms. Edge costs use milli-paise per kilogram. The displayed costs and schedules are illustrative demo data and are not live carrier quotes.")));return p;}

    private JPanel vertical(){JPanel p=new JPanel();p.setBackground(BG);p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));p.setBorder(new EmptyBorder(0,0,0,0));return p;}
    private JPanel metric(String label,String value,String note,String icon){JPanel p=new JPanel(new BorderLayout(0,9));p.setBackground(Color.WHITE);p.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(229,232,237)),new EmptyBorder(16,17,15,17)));JLabel l=new JLabel(label);l.setForeground(MUTED);l.setFont(new Font("Monospaced",Font.BOLD,9));JLabel v=new JLabel(value);v.setForeground(INK);v.setFont(new Font("SansSerif",Font.BOLD,23));JLabel n=new JLabel(note);n.setForeground(MUTED);n.setFont(new Font("SansSerif",Font.PLAIN,10));JLabel i=new JLabel(icon);i.setForeground(RED);i.setFont(new Font("SansSerif",Font.BOLD,19));JPanel top=new JPanel(new BorderLayout());top.setOpaque(false);top.add(l,BorderLayout.WEST);top.add(i,BorderLayout.EAST);JPanel center=new JPanel();center.setOpaque(false);center.setLayout(new BoxLayout(center,BoxLayout.Y_AXIS));center.add(v);center.add(n);p.add(top,BorderLayout.NORTH);p.add(center,BorderLayout.CENTER);return p;}
    private JPanel card(String title,Component child){JPanel p=new JPanel(new BorderLayout());p.setBackground(Color.WHITE);p.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(229,232,237)),new EmptyBorder(15,16,15,16)));JLabel h=new JLabel(title);h.setForeground(INK);h.setFont(new Font("SansSerif",Font.BOLD,14));h.setBorder(new EmptyBorder(0,0,14,0));p.add(h,BorderLayout.NORTH);p.add(child instanceof JTable table ? new JScrollPane(table) : child,BorderLayout.CENTER);p.setAlignmentX(Component.LEFT_ALIGNMENT);p.setMaximumSize(new Dimension(Integer.MAX_VALUE,500));return p;}
    private JPanel field(String label,Component c){JPanel p=new JPanel();p.setBackground(Color.WHITE);p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));JLabel l=new JLabel(label);l.setForeground(MUTED);l.setFont(new Font("Monospaced",Font.BOLD,9));l.setBorder(new EmptyBorder(0,0,6,0));c.setMaximumSize(new Dimension(Integer.MAX_VALUE,34));p.add(l);p.add(c);return p;}
    private JTable styledTable(DefaultTableModel model){JTable t=new JTable(model);t.setRowHeight(36);t.setFont(new Font("SansSerif",Font.PLAIN,12));t.setForeground(INK);t.setGridColor(new Color(235,237,240));t.setFillsViewportHeight(true);t.getTableHeader().setFont(new Font("Monospaced",Font.BOLD,9));t.getTableHeader().setForeground(MUTED);t.getTableHeader().setBackground(new Color(248,249,251));t.setAutoCreateRowSorter(true);JScrollPane scroll=new JScrollPane(t);scroll.setBorder(BorderFactory.createEmptyBorder());return t;}
    private JButton primary(String label){JButton b=new JButton(label);b.setBackground(RED);b.setForeground(Color.WHITE);b.setFocusPainted(false);b.setBorder(new EmptyBorder(10,14,10,14));b.setFont(new Font("SansSerif",Font.BOLD,12));return b;}
    private JLabel text(String value){JLabel l=new JLabel("<html><div style='width:420px;line-height:1.6'>"+value+"</div></html>");l.setForeground(MUTED);l.setFont(new Font("SansSerif",Font.PLAIN,13));return l;}
    private String money(double amount){return NumberFormat.getCurrencyInstance(new Locale("en","IN")).format(amount);}
}
