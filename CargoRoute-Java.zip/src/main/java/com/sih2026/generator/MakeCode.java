package com.sih2026.generator;

import java.io.IOException;

/** Java replacement for make_code.py. */
public final class MakeCode {
    private MakeCode() {
    }

    public static void write(String filePath, String content) throws IOException {
        FileGenerationSupport.writeText(filePath, content, "Wrote");
    }
}
