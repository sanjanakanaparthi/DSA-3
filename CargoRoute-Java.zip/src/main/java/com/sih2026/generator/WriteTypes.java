package com.sih2026.generator;

/**
 * Placeholder for write_types.py, which contained no executable code.
 * Type definitions remain part of the TypeScript application source.
 */
public final class WriteTypes {
    private WriteTypes() {
    }
}
